<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "contactUs";

//Insert data
$name=$_POST['name'];
$num=$_POST['num'];
$emai=$_POST['email'];
$comm=$_POST['comm'];

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$sql = "INSERT INTO `contacts` (`SrNo`, `Name`, `num`, `Email`, `msg`, `At`)
VALUES ('', '$name', $num, $email, '$comm' now(););";
?>