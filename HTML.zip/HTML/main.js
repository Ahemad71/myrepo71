console.log('Hello World!');
let name=document.getElementById('name').value;
document.write(name);